package com.testing;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class A2 {
public static void main(String[] args) {
	
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Desktop\\lib\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
driver.get("https://www.phptravels.net/admin");
//driver.findElement(By.linkText("admin")).click();
driver.findElement(By.name("email")).sendKeys("admin@phptravels.com");
driver.findElement(By.name("password")).sendKeys("demoadmin");
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
driver.findElement(By.xpath("(//button)")).click();
driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
driver.findElement(By.xpath("//ul[@id='social-sidebar-menu']/li[5]/a")).click();
driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
driver.findElement(By.xpath("//li[5]/ul/li[3]/a")).click();
driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
driver.findElement(By.xpath("//div[@id='content']/div[2]/form/button")).click();

driver.findElement(By.name("fname")).sendKeys("abc");
driver.findElement(By.name("lname")).sendKeys("xyz");
driver.findElement(By.name("email")).sendKeys("ump@gmail.com");
driver.findElement(By.name("password")).sendKeys("polaris");
driver.findElement(By.name("mobile")).sendKeys("ghi");
Select country = new Select(driver.findElement(By.name("country")));

country.selectByVisibleText("India");
driver.findElement(By.name("address1")).sendKeys("mno");
driver.findElement(By.name("address2")).sendKeys("mnofrd");
Select status= new Select(driver.findElement(By.name("status")));

status.selectByVisibleText("Enabled");

WebElement option1 = driver.findElement(By.xpath("//div[@id='content']/form/div/div[2]/div/div[13]/div/div/label/strong"));							

// This will Toggle the Check box 		
option1.click();	
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
driver.findElement(By.xpath("//div[@id='content']/form/div/div[3]/button")).click();
driver.findElement(By.id("36")).click();

}
	
	
}
