package com.testing;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class A1 {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Desktop\\lib\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
driver.get("http://the-internet.herokuapp.com/javascript_alerts");
	//driver.findElement(By.linkText("REGISTER")).click();

driver.findElement(By.xpath("(//button[1])")).click();
driver.switchTo().alert().dismiss();
driver.findElement(By.xpath("(//button[2])")).click();
driver.switchTo().alert().dismiss();
driver.findElement(By.xpath("(//button[3])")).click();
driver.switchTo().alert().sendKeys("abc");
driver.switchTo().alert().accept();



/*WebDriverWait wait = new WebDriverWait(driver, 10);*/
/*driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS)*/;
	}
}
