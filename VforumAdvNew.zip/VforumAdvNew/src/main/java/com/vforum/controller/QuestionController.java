package com.vforum.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.enterprise.inject.Model;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.vforum.model.Answer;
import com.vforum.model.Employee;
import com.vforum.model.Question;
import com.vforum.model.ReportAnswer;
import com.vforum.model.ReportQuestion;
import com.vforum.services.VforumServiceIface;

@Controller
public class QuestionController {

	@Autowired
	VforumServiceIface vforumServiceIface;
	
	@RequestMapping("/searchQues")
	public ModelAndView searchQuestion(@RequestParam("search")String searchText) {
		ModelAndView modelAndView=new ModelAndView();
		List<Question> searchQuestions=vforumServiceIface.searchQuestion(searchText);
		modelAndView.addObject("allsearchQuestions",searchQuestions);
		modelAndView.setViewName("Search");
		return modelAndView;
	}
	
	@RequestMapping("/addquestion")
	public ModelAndView addQuestion(@RequestParam("categories")String categories,@RequestParam("question")String question,HttpSession session) {
		ModelAndView mv=new ModelAndView();
		Employee curEmp=(Employee)session.getAttribute("curuser");
		Question q=new Question();
		try {
			q.setDatecreated(new SimpleDateFormat("yyyy-MM-dd").parse(new SimpleDateFormat("yyyy-MM-dd").format(new Date())));
			q.setDateUpdated(new SimpleDateFormat("yyyy-MM-dd").parse(new SimpleDateFormat("yyyy-MM-dd").format(new Date())));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		q.setDesig(curEmp.getDesig());
		q.setUserName(curEmp.getUsername());
		q.setTitle(categories);
		q.setQuestion(question);
		vforumServiceIface.addQuestion(q);
		mv.setViewName("redirect:mainpage.vforum");
		return mv;
	}
	
	@RequestMapping("/addanswer")
	public ModelAndView addAnswer(@RequestParam("qid")int qid,@RequestParam("answer")String answer,HttpSession session) {
		ModelAndView mv=new ModelAndView();
		Employee curEmp=(Employee)session.getAttribute("curuser");
		Answer a=new Answer();
		a.setAnswer(answer);
		a.setQid(qid);
		Date answerDate=null;
		try {
			answerDate = new SimpleDateFormat("yyyy-MM-dd").parse(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		a.setAnswerDate(answerDate);
		a.setUsernameAnswer(curEmp.getUsername());
		vforumServiceIface.addAnswer(a);
		mv.setViewName("redirect:mainpage.vforum");
		return mv;
	}
	
	@RequestMapping("/mainpage")
	public ModelAndView toMainPage(){
		ModelAndView mv=new ModelAndView();
		List<Question> allques=vforumServiceIface.getAllQuestions();
		mv.addObject("allques",allques);
		mv.setViewName("main");
		return mv;
	}
	
	@RequestMapping("/code")
	public ModelAndView toCodePage(){
		String cat="code";
		ModelAndView mv=new ModelAndView();
		List<Question> allques=vforumServiceIface.getAllQuestionByCategory(cat);
		mv.addObject("allques",allques);
		mv.setViewName("Code");
		return mv;
	}
	@RequestMapping("/onboarding")
	public ModelAndView toOnbardingPage(){
		String cat="onboarding";
		ModelAndView mv=new ModelAndView();
		List<Question> allques=vforumServiceIface.getAllQuestionByCategory(cat);
		mv.addObject("allques",allques);
		mv.setViewName("Onboarding");
		return mv;
	}
	@RequestMapping("/payroll")
	public ModelAndView toPayrollPage(){
		String cat="payroll";
		ModelAndView mv=new ModelAndView();
		List<Question> allques=vforumServiceIface.getAllQuestionByCategory(cat);
		mv.addObject("allques",allques);
		mv.setViewName("Payroll");
		return mv;
	}
	@RequestMapping("/policies")
	public ModelAndView toPoliciesPage(){
		String cat="policies";
		ModelAndView mv=new ModelAndView();
		List<Question> allques=vforumServiceIface.getAllQuestionByCategory(cat);
		mv.addObject("allques",allques);
		mv.setViewName("Policies");
		return mv;
	}
	@RequestMapping("/technical")
	public ModelAndView toTechnicalPage(){
		String cat="technical";
		ModelAndView mv=new ModelAndView();
		List<Question> allques=vforumServiceIface.getAllQuestionByCategory(cat);
		mv.addObject("allques",allques);
		mv.setViewName("Technical");
		return mv;
	}
	
	@RequestMapping("/reportquestion")
	public String reportQuestion(@RequestParam("qid")String qid,@RequestParam("report")String report,HttpSession session) {
		ReportQuestion reportQuestion=new ReportQuestion();
		reportQuestion.setQuesId(Integer.parseInt(qid));
		reportQuestion.setReportStatement(report);
		vforumServiceIface.reportQuestion(reportQuestion);
		return "redirect:mainpage.vforum";
	}
	
	@RequestMapping("/reportanswer")
	public String reportAnswer(@RequestParam("qid")String qid,@RequestParam("aid")String aid,@RequestParam("rptAns")String report,HttpSession session) {
		ReportAnswer reportAnswer=new ReportAnswer();
		reportAnswer.setQuesId(Integer.parseInt(qid));
		reportAnswer.setAnsId(Integer.parseInt(aid));
		reportAnswer.setReportStatement(report);
		vforumServiceIface.reportAnswer(reportAnswer);
		return "redirect:mainpage.vforum";
	}
}
