package com.vforum.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.vforum.services.VforumServiceIface;
import com.vforum.model.Employee;
import com.vforum.model.Question;




@Controller
public class EmployeeControllers {
	
	@Autowired
	VforumServiceIface vforumServiceIface;
	@RequestMapping("/")
	public String toDefaultpage() {
		return "index";
	}
	@RequestMapping("/LoginPage")
	public ModelAndView takeToLogin(HttpSession session) {
		ModelAndView mv=new ModelAndView();
		if (session.getAttribute("curuser") != null) {
			mv.setViewName("main");
		} else {
			mv.setViewName("login");
		}
		return mv;
	}
	
	@RequestMapping("/changePassword")
	public ModelAndView changePassword(@RequestParam("newpwd")String newpwd,@RequestParam("curPwd")String curPassword,HttpSession session) {
		ModelAndView modelAndView=new ModelAndView();
		Employee employee=(Employee)session.getAttribute("curuser");
		if(vforumServiceIface.loginEmp(employee.getEmail(), curPassword)!=null) {
			if(vforumServiceIface.changePassword(employee, newpwd)) {
				modelAndView.addObject("msg", "<span style=\"color:green;font-size:20px;\">Updated password succesfully!</span>");
				modelAndView.setViewName("Settings");
			}else {
				modelAndView.addObject("msg", "<span style=\"color:red;font-size:20px;\">Some problem occurred! Try again</span>");
				modelAndView.setViewName("Settings");
			}
		}
		else {
			modelAndView.addObject("msg", "<span style=\"color:red;font-size:20px;\">Old password is incorrect!</span>");
			modelAndView.setViewName("Settings");
		}
		return modelAndView;
	}
	
	@RequestMapping("/RegisterPage")
	public String takeToReg() {
		return "Register";
	}
	
	@RequestMapping("/register")
	public String regsiteruser(Employee employee ) {
		vforumServiceIface.registerEmp(employee);
		return "login";
	}
	
	@RequestMapping("/login")
	public ModelAndView loginuser(@RequestParam("euname") String email,@RequestParam("epass") String pass,HttpSession session,Model m) {
		Employee emp = vforumServiceIface.loginEmp(email, pass);
		ModelAndView mv = new ModelAndView();
		String ademail="admin@virtusa.com";
		String adpass="Admin@123";
		
		if(email.equals(ademail)& pass.equals(adpass)) {
			mv.setViewName("redirect:admin.vforum");
			
		}else {
		
		if (emp != null) {
			// m.addAttribute("msg","succesfull");
			session.setAttribute("curuser", emp);
			List<Question> allques = vforumServiceIface.getAllQuestions();
			mv.addObject("allques", allques);
			mv.setViewName("main");
		} else {
			mv.addObject("msg", "Wrong credentials");
			mv.addObject("cssprop","animation: shake 0.5s;animation-iteration-count: once;color: black;background-color:#ff2222;transition:all 2s;");
			mv.setViewName("login");
		}
		}
		return mv;
	}
}

