
package com.vforum.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.vforum.model.Answer;
import com.vforum.model.Contactus;
import com.vforum.model.Employee;
import com.vforum.model.Question;
import com.vforum.model.ReportAnswer;
import com.vforum.model.ReportQuestion;
import com.vforum.model.ReportedQuestions;
import com.vforum.services.VforumAdminServiceIface;

@Controller
public class AdminController {

	@Autowired
	VforumAdminServiceIface vforumAdminServiceIface;

	@RequestMapping("/admin")
	public ModelAndView allProfileData(HttpSession session) {

		List<ReportedQuestions> allReportQues = vforumAdminServiceIface.getreportQuestion();
		List<ReportAnswer> allReportAns = vforumAdminServiceIface.getreportAnswer();
		List<Employee> emp = vforumAdminServiceIface.getAllEmployees();
		List<Contactus> allcontactus=vforumAdminServiceIface.getallContactUs();

		ModelAndView mv = new ModelAndView();
		mv.addObject("allreportques", allReportQues);
		mv.addObject("allreportans", allReportAns);
		mv.addObject("allemp", emp);
		mv.addObject("allcontactus", allcontactus);
		mv.setViewName("AdminIndex");
		return mv;
	}

	@RequestMapping("/admin/que/{qid}")
	public String deleteReportedQuestion(@PathVariable("qid") int qid) {
		boolean flag = vforumAdminServiceIface.deleteQuestion(qid);
		String path = null;
		if (flag) {
			path = "redirect:/admin.vforum";
		} else {
			path = "redirect:/admin.vforum";
		}
		return path;
	}

	@RequestMapping("/admin/ans/{aid}")
	public String deleteReportedAnswer(@PathVariable("aid") int aid) {
		boolean flag = vforumAdminServiceIface.deleteAnswer(aid);
		String path = null;
		if (flag) {
			path = "redirect:/admin.vforum";
		} else {
			path = "redirect:/admin.vforum";
		}
		return path;
	}
	
}
