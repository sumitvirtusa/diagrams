package com.vforum.controller;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.vforum.model.Question;
import com.vforum.services.VforumServiceIface;
@RestController
public class QuestionRestController {
	@Autowired
	VforumServiceIface vforumServiceIface;
	
	@GetMapping(value="rest/getall",produces = "application/json")
	public List<Question> getAllQuestions() {
		return vforumServiceIface.getAllQuestions();
	}
	
	@GetMapping(value="rest/question/by/{cat}",produces = "application/json")
	public List<Question> getAllQuestionByCategory(@PathVariable("cat") String cat){
		return vforumServiceIface.getAllQuestionByCategory(cat);
	}
}
