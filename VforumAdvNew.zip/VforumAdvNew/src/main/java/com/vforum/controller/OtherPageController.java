package com.vforum.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.vforum.model.Answer;
import com.vforum.model.Contactus;
import com.vforum.model.Employee;
import com.vforum.model.Question;
import com.vforum.services.VforumServiceIface;

@Controller
public class OtherPageController {
	@Autowired
	VforumServiceIface vforumServiceIface;
	
	@RequestMapping("/profile")
	public ModelAndView allProfileData(HttpSession session) {
		Employee u = (Employee) session.getAttribute("curuser");
		List<Question> allRecentQues = vforumServiceIface.getAllQuestionByLoginUser(u.getUsername());
		List<Answer> allAnsByUser=vforumServiceIface.getAllAnsweredByLoginUser(u.getUsername());
		System.out.println("allquestions "+allRecentQues);
		ModelAndView mv=new ModelAndView();
		mv.addObject("empinfo",u);
		mv.addObject("allquesbyuser",allRecentQues);
		mv.addObject("allansbyuser",allAnsByUser);
		mv.setViewName("Profile");
		return mv;
	}

	@RequestMapping("/setting")
	public String toSettingPage() {
		return "Settings";
	}

	@RequestMapping("/aboutus")
	public String toAboutUsPage() {
		return "AboutUs";
	}

	@RequestMapping("/contactus")
	public String toContactUsPage() {
		return "Contact";
	}
	
	@RequestMapping("/saveContactus")
	public ModelAndView saveContactUs(Contactus contactus) {
		ModelAndView modelAndView=new ModelAndView();
		String msg=vforumServiceIface.saveContactUs(contactus);
		modelAndView.addObject("msg",msg);
		modelAndView.setViewName("Contact");
		return modelAndView;
	}
	
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.removeAttribute("curuser");
		session.invalidate();
		return "login";
	}
}
