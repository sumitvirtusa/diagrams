package com.vforum.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="employee_reg")
public class Employee {
@Id
@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "empid_generator")
@SequenceGenerator(name="empid_generator", sequenceName = "author_seq")
private int id;
@Column
private String fname;
@Column
private String lname;
@Column
private int employeeId;
@Column
//@Temporal(TemporalType.DATE)
//@DateTimeFormat(pattern = "yyyy-MM-dd")
private String dob;
@Column
private String email;
@Column
private String username;
@Column
private String passkey;
@Column
private String desig;
@Column
private String location;


public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getDesig() {
	return desig;
}
public void setDesig(String desig) {
	this.desig = desig;
}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public String getLname() {
	return lname;
}
public void setLname(String lname) {
	this.lname = lname;
}
public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}

public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPasskey() {
	return passkey;
}
public void setPasskey(String passkey) {
	this.passkey = passkey;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}

@Override
public String toString() {
	return "employee [id=" + id + ", fname=" + fname + ", lname=" + lname + ", employeeId=" + employeeId + ", dob="
			+ dob + ", email=" + email + ", username=" + username + ", passkey=" + passkey + ", location=" + location
			+ "]";
}


}
