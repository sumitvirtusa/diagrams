package com.vforum.model;


import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

@Entity
@Table(name="questions")
public class Question {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int questionId;
	@Temporal(TemporalType.DATE)
	private Date datecreated;
	@Temporal(TemporalType.DATE)
	private Date dateUpdated;
	@Column(length = 2000)
	private String question;
	private String title;
	private String userName;
	private String desig;
	
	@OneToMany(mappedBy ="question" ,cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	private List<Answer> answers;
	
	@OneToMany(mappedBy ="rQuestion" ,cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	private List<ReportQuestion> reportQuestion;
	
	@OneToMany(mappedBy ="rQuesId" ,cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	private List<ReportAnswer> reportAnswerQuesId;
	
	public List<ReportQuestion> getReportQuestion() {
		return reportQuestion;
	}
	public void setReportQuestion(List<ReportQuestion> reportQuestion) {
		this.reportQuestion = reportQuestion;
	}
	public List<ReportAnswer> getReportAnswerQuesId() {
		return reportAnswerQuesId;
	}
	public void setReportAnswerQuesId(List<ReportAnswer> reportAnswerQuesId) {
		this.reportAnswerQuesId = reportAnswerQuesId;
	}
	@Override
	public String toString() {
		return "Question [questionId=" + questionId + ", datecreated=" + datecreated + ", dateUpdated=" + dateUpdated
				+ ", question=" + question + ", title=" + title + ", userName=" + userName + ", desig=" + desig
				+ ", answers=" + answers + "]";
	}
	public List<Answer> getAnswers() {
		return answers;
	}
	public void setAnswers(List<Answer> answers) {
		this.answers = answers;
	}
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getDesig() {
		return desig;
	}
	public void setDesig(String desig) {
		this.desig = desig;
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public void setDatecreated(Date datecreated) {
		this.datecreated = datecreated;
	}
	public void setDateUpdated(Date dateUpdated) {
		this.dateUpdated = dateUpdated;
	}
	public Date getDatecreated() {
		return datecreated;
	}
	public Date getDateUpdated() {
		return dateUpdated;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = "<pre>"+question+"</pre>";
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
}
