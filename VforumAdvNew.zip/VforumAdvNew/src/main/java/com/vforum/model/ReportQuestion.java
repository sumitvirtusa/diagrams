package com.vforum.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ManyToAny;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="report_question")
public class ReportQuestion{
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	int reportId;
	String reportStatement;
	int quesId;
	
	@ManyToOne
	@JsonIgnore 
	@JoinColumn(name="quesId",referencedColumnName = "questionId",insertable = false, updatable = false)
	Question rQuestion;
	
	public Question getrQuestion() {
		return rQuestion;
	}
	public void setrQuestion(Question rQuestion) {
		this.rQuestion = rQuestion;
	}
	public int getReportId() {
		return reportId;
	}
	public void setReportId(int reportId) {
		this.reportId = reportId;
	}
	public String getReportStatement() {
		return reportStatement;
	}
	public void setReportStatement(String reportStatement) {
		this.reportStatement = reportStatement;
	}
	public int getQuesId() {
		return quesId;
	}
	public void setQuesId(int quesId) {
		this.quesId = quesId;
	}
	
}
