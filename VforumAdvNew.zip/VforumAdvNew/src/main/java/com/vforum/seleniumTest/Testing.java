package com.vforum.seleniumTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Testing {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
	driver.get("http://localhost:8080/VforumAdvNew/");
	//driver.findElement(By.xpath("//button[@onclick=\"window.open('LoginPage.vforum','_self')\"]")).click();
	//driver.findElement(By.xpath("//button[contains(.,'Register')]")).click();
	driver.findElement(By.xpath("//button[contains(.,'Login')]")).click();
	
		
//		  driver.findElement(By.name("fname")).sendKeys("Demo");
//		  driver.findElement(By.name("lname")).sendKeys("Test");
//		  driver.findElement(By.name("employeeId")).sendKeys("123");
//		  driver.findElement(By.name("dob")).sendKeys("01/01/2000");
//		  driver.findElement(By.name("desig")).sendKeys("polaris");
//		  driver.findElement(By.name("email")).sendKeys("demo@virtusa.com");
//		  driver.findElement(By.name("username")).click();
//		  driver.findElement(By.name("passkey")).sendKeys("Demo@123");
//		  driver.findElement(By.name("location")).sendKeys("Delhi");
//		  driver.findElement(By.xpath("//input[@value='SUBMIT']")).click();
		 
	 
	  driver.findElement(By.name("euname")).sendKeys("demo@virtusa.com");
	  driver.findElement(By.name("epass")).sendKeys("Demo@123");

	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  driver.findElement(By.xpath("//input[@value='Login']")).click();
	  
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  driver.findElement(By.xpath("(//button[@type='button'])[2]")).click();
	  driver.findElement(By.name("question")).sendKeys("why selenium testing is required");

	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  driver.findElement(By.xpath("//button[contains(.,'Post Question')]")).click();

	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  driver.findElement(By.xpath("//button[contains(.,'Answer')]")).click();
	  driver.findElement(By.name("answer")).sendKeys("Selenium automation framework is very easy-to-use tool. Selenium provides a user-friendly interface that helps create and execute test scripts easily and effectively. You can also watch while tests are running.");

	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  driver.findElement(By.xpath("//div[2]/div/div/div/div[2]/form/button")).click();

	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  driver.findElement(By.xpath("//button[contains(.,'Report this question')]")).click();

	  driver.findElement(By.name("report")).sendKeys("Duplicate  Question");

	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  driver.findElement(By.xpath("//div[2]/div[2]/div/div/div[2]/form/button")).click();
	  
	  driver.findElement(By.linkText("Technical")).click();
	  driver.findElement(By.linkText("Payroll")).click();
	  driver.findElement(By.linkText("Policies")).click();
	  driver.findElement(By.linkText("Onboarding")).click();
	  driver.findElement(By.linkText("Code")).click();
	  driver.findElement(By.linkText("View all")).click();
	  driver.findElement(By.id("navbardrop")).click();
	  driver.findElement(By.linkText("Profile")).click();
	  driver.findElement(By.id("navbardrop")).click();
	  driver.findElement(By.linkText("About us")).click();
	  driver.findElement(By.id("navbardrop")).click();
	  driver.findElement(By.linkText("Settings")).click();
	  driver.findElement(By.id("navbardrop")).click();
	  driver.findElement(By.linkText("Contact us")).click();
	  driver.findElement(By.id("navbardrop")).click();
	  driver.findElement(By.linkText("Logout")).click();
	  
	  
	  
	  
	  
	  /*
		 * Select country = new Select(driver.findElement(By.name("country")));
		 * driver.findElement(By.name("fname")).sendKeys("admin@phptravels.com");
		 * driver.findElement(By.name("lname")).sendKeys("demoadmin");
		 * //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 * driver.findElement(By.xpath("(//button)")).click();
		 * driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 * driver.findElement(By.xpath("//ul[@id='social-sidebar-menu']/li[5]/a")).click
		 * (); driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 * driver.findElement(By.xpath("//li[5]/ul/li[3]/a")).click();
		 * driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 * driver.findElement(By.xpath("//div[@id='content']/div[2]/form/button")).click
		 * ();
		 * 
		 * driver.findElement(By.name("fname")).sendKeys("abc");
		 * driver.findElement(By.name("lname")).sendKeys("xyz");
		 * driver.findElement(By.name("email")).sendKeys("ump@gmail.com");
		 * driver.findElement(By.name("password")).sendKeys("polaris");
		 * driver.findElement(By.name("mobile")).sendKeys("ghi"); Select country = new
		 * Select(driver.findElement(By.name("country")));
		 */
	}
}
