/**
 * 
 */
package com.vforum.seleniumTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * @author sumit
 *
 */
public class AdminTesting {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
	    driver.get("http://localhost:8080/VforumAdvNew/");
	    driver.findElement(By.xpath("//button[contains(.,'Login')]")).click();
	    driver.findElement(By.name("euname")).sendKeys("admin@virtusa.com");
		  driver.findElement(By.name("epass")).sendKeys("Admin@123");
		  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		  driver.findElement(By.xpath("//input[@value='Login']")).click();
		  driver.findElement(By.linkText("Reported Questions")).click();
		  driver.findElement(By.linkText("Reported Answers")).click();
		  driver.findElement(By.linkText("Users")).click();
		  driver.findElement(By.linkText("Contact Us")).click();
	      driver.findElement(By.id("navbardrop")).click();
	      driver.findElement(By.linkText("Logout")).click();
		 
	}
}
