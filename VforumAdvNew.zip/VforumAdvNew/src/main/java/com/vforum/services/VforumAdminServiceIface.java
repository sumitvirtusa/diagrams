package com.vforum.services;

import java.util.List;

import org.hibernate.Session;

import com.vforum.model.Answer;
import com.vforum.model.Contactus;
import com.vforum.model.Employee;
import com.vforum.model.Question;
import com.vforum.model.ReportAnswer;
import com.vforum.model.ReportedQuestions;

public interface VforumAdminServiceIface {
	public List<ReportedQuestions> getreportQuestion();
	public List<ReportAnswer> getreportAnswer();
	public Question QuestionById(int quesid);
	public Answer AnswerById(int ansid);
	public List<Employee> getAllEmployees();
	public boolean deleteQuestion(int qid);
	public boolean deleteAnswer(int aid);
	public List<Contactus> getallContactUs();
}
