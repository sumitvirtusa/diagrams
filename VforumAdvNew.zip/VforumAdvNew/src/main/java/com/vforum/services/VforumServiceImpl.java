package com.vforum.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vforum.daos.VforumDaoImpl;
import com.vforum.daos.VforumDaoIface;
import com.vforum.model.Answer;
import com.vforum.model.Contactus;
import com.vforum.model.Employee;
import com.vforum.model.Question;
import com.vforum.model.ReportAnswer;
import com.vforum.model.ReportQuestion;
import com.vforum.model.ReportedQuestions;
@Service
@Transactional
public class VforumServiceImpl implements VforumServiceIface {
	@Autowired
	VforumDaoIface vforumDaoIface;
	
	
	public int registerEmp(Employee employee) {
		return vforumDaoIface.registerEmp(employee);
	}
	
	public Employee loginEmp(String username, String passkey) {
		return vforumDaoIface.loginEmp(username, passkey);
	}
	public List<Question> getAllQuestions() {
		return vforumDaoIface.getAllQuestions();
	}
	
	public int addQuestion(Question question) {
		return vforumDaoIface.addQuestion(question);
	}
	
	public int addAnswer(Answer answer) {
		return vforumDaoIface.addAnswer(answer);
	}
	public List<Question> getAllQuestionByCategory(String cat){
		return vforumDaoIface.getAllQuestionByCategory(cat);
	}
	public List<Question> getAllQuestionByLoginUser(String username){
		return vforumDaoIface.getAllQuestionByLoginUser(username);
	}
	public List<Answer> getAllAnsweredByLoginUser(String username) {
		return vforumDaoIface.getAllAnsweredByLoginUser(username);
	}
	
	public int reportQuestion(ReportQuestion reportQuestion) {
		return vforumDaoIface.reportQuestion(reportQuestion);
	}
	
	public int reportAnswer(ReportAnswer reportAnswer) {
		return vforumDaoIface.reportAnswer(reportAnswer);
	}

	public boolean changePassword(Employee employee, String newPassKey) {
		return vforumDaoIface.changePassword(employee, newPassKey);
	}

	public String saveContactUs(Contactus contactus) {
		return vforumDaoIface.saveContactUs(contactus);
	}

	public List<Question> searchQuestion(String searchText) {
		return vforumDaoIface.searchQuestion(searchText);
	}
}
