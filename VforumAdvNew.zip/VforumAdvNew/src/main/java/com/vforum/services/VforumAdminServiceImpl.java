package com.vforum.services;

import java.util.List;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vforum.daos.VforumAdminDaoIface;
import com.vforum.model.Answer;
import com.vforum.model.Contactus;
import com.vforum.model.Employee;
import com.vforum.model.Question;
import com.vforum.model.ReportAnswer;
import com.vforum.model.ReportedQuestions;
@Service
@Transactional
public class VforumAdminServiceImpl implements VforumAdminServiceIface {
	@Autowired
	VforumAdminDaoIface vforumAdminDaoIface ;
	
	public List<ReportedQuestions> getreportQuestion() {
		return vforumAdminDaoIface.getreportQuestion();
	}
	public List<ReportAnswer> getreportAnswer() {
		
		return vforumAdminDaoIface.getreportAnswer();
	}
	public Question QuestionById(int quesid) {
		
		return vforumAdminDaoIface.QuestionById(quesid);
	}
	public Answer AnswerById(int ansid) {
		
		return vforumAdminDaoIface.AnswerById(ansid);
	}
	public List<Employee> getAllEmployees() {
		return vforumAdminDaoIface.getAllEmployees();
	}
	
	public boolean deleteQuestion(int qid) {
		return vforumAdminDaoIface.deleteQuestion(qid);
	}
	
	public boolean deleteAnswer(int aid) {
		return vforumAdminDaoIface.deleteAnswer(aid);
	}
	public List<Contactus> getallContactUs() {
		return vforumAdminDaoIface.getallContactUs();
	}

}
