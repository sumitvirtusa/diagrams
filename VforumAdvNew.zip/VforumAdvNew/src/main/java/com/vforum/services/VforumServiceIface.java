package com.vforum.services;

import java.util.List;

import com.vforum.model.Answer;
import com.vforum.model.Contactus;
import com.vforum.model.Employee;
import com.vforum.model.Question;
import com.vforum.model.ReportAnswer;
import com.vforum.model.ReportQuestion;
import com.vforum.model.ReportedQuestions;

public interface VforumServiceIface {

public int registerEmp(Employee employee);
public Employee loginEmp(String username,String passkey);
public List<Question> getAllQuestions();
public int addQuestion(Question question);
public int addAnswer(Answer answer);
public List<Question> getAllQuestionByCategory(String cat);
public List<Question> getAllQuestionByLoginUser(String username);
public List<Answer> getAllAnsweredByLoginUser(String username);
public int reportQuestion(ReportQuestion reportQuestion);
public int reportAnswer(ReportAnswer reportAnswer);
public boolean changePassword(Employee employee,String newPassKey);
public String saveContactUs(Contactus contactus);
public List<Question> searchQuestion(String searchText);
}
