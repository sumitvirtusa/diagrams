package com.vforum.daos;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.vforum.model.Answer;
import com.vforum.model.Contactus;
import com.vforum.model.Employee;
import com.vforum.model.Question;
import com.vforum.model.ReportAnswer;
import com.vforum.model.ReportQuestion;
import com.vforum.model.ReportedQuestions;

@Repository
public class VforumAdminDaoImpl implements VforumAdminDaoIface {
	@Autowired
	SessionFactory sessionFactory;

	// Reported question
	public List<ReportedQuestions> getreportQuestion() {
		Session session = sessionFactory.getCurrentSession();
		Query q = session.createQuery("from ReportQuestion q order by q.id desc");
		List<ReportQuestion> allques = (List<ReportQuestion>) q.list();
		List<ReportedQuestions> allreportedQuestions = new ArrayList<ReportedQuestions>();
		for (ReportQuestion reportQuestion : allques) {
			Question question = this.QuestionById(reportQuestion.getQuesId());
			ReportedQuestions reportedQuestions = new ReportedQuestions();
			reportedQuestions.setQuesId(reportQuestion.getQuesId());
			reportedQuestions.setQuesCreateDate(question.getDatecreated());
			reportedQuestions.setQuesCreateUser(question.getUserName());
			reportedQuestions.setQuesCreateUserDesig(question.getDesig());
			reportedQuestions.setQuestionReportText(reportQuestion.getReportStatement());
			reportedQuestions.setQuestionText(question.getQuestion());
			allreportedQuestions.add(reportedQuestions);
		}
		
		return allreportedQuestions;
	}

	// Report Answer
	public List<ReportAnswer> getreportAnswer() {
		Session session = sessionFactory.getCurrentSession();
		Query q = session.createQuery("from ReportAnswer q order by q.id desc");
		List<ReportAnswer> allans = (List<ReportAnswer>) q.list();
		System.out.println(allans);
		return allans;

	}

	public Question QuestionById(int quesid) {
		Session session=sessionFactory.getCurrentSession();
		Question question = (Question) session.get(Question.class, quesid);
		System.out.println("questiuinsbdj"+question.getQuestion());
		return question;
	}

	public Answer AnswerById(int ansid) {
		Session session=sessionFactory.getCurrentSession();
		Answer answer = (Answer) session.get(Answer.class, ansid);
		return answer;
	}

	public List<Employee> getAllEmployees() {
		Session session = sessionFactory.getCurrentSession();
		Query q = session.createQuery("from Employee");
		List<Employee> allEmployees = q.list();
		return allEmployees;
	}

	public boolean deleteQuestion(int qid) {
		boolean flag = false;
		Session session = sessionFactory.getCurrentSession();
		session.delete(this.QuestionById(qid));
		flag = true;
		return flag;
	}

	public boolean deleteAnswer(int aid) {
		boolean flag = false;
		Session session = sessionFactory.getCurrentSession();
		Answer answer=this.AnswerById(aid);
		List<ReportAnswer> allReportAnswers=answer.getReportAnswer();
		answer.getReportAnswer().removeAll(allReportAnswers);
		session.delete(answer);
		flag = true;
		return flag;
	}

	public List<Contactus> getallContactUs() {
		Session session = sessionFactory.getCurrentSession();
		Query q = session.createQuery("from Contactus");
		List<Contactus> allContactus = q.list();
		return allContactus;
	}
}
