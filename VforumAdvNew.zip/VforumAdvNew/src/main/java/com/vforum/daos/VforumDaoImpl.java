package com.vforum.daos;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.vforum.model.Answer;
import com.vforum.model.Contactus;
import com.vforum.model.Employee;
import com.vforum.model.Question;
import com.vforum.model.ReportAnswer;
import com.vforum.model.ReportQuestion;
import com.vforum.model.ReportedQuestions;

@Repository
public class VforumDaoImpl implements VforumDaoIface {
	@Autowired
	SessionFactory sessionFactory;

	public int registerEmp(Employee employee) {
		Session session = sessionFactory.getCurrentSession();
		int saved = (Integer) session.save(employee);
//		Transaction transaction=session.beginTransaction();
//		transaction.commit();

		return saved;
	}

	public boolean changePassword(Employee employee, String newPassKey) {
		Session session = sessionFactory.getCurrentSession();
		employee.setPasskey(newPassKey);
		try {
			session.update(employee);
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	public Employee loginEmp(String email, String passkey) {
		Session session = sessionFactory.getCurrentSession();
		Query q = session.createQuery("from Employee where email=:email and passkey=:pass");
		q.setParameter("email", email);
		q.setParameter("pass", passkey);
		Employee e = null;
		List l = q.list();
		if (l.size() > 0) {
			e = (Employee) l.get(0);
		}

		return e;
	}

	// get All Questions
	public List<Question> getAllQuestions() {
		Session session = sessionFactory.getCurrentSession();
		Query q = session.createQuery("from Question q order by q.datecreated desc");
		List<Question> allques = q.list();
		System.out.println("size of ques" + allques.size());
		System.out.println(allques);

		return allques;
	}

	// add Question
	public int addQuestion(Question question) {
		Session session = sessionFactory.getCurrentSession();
		int check = (Integer) session.save(question);
		if (check > 0) {
//		Transaction transaction=session.beginTransaction();
//		transaction.commit();
		}

		return check;
	}

	// add Answer
	public int addAnswer(Answer answer) {
		Session session = sessionFactory.getCurrentSession();
		int check = (Integer) session.save(answer);
		System.out.println("outside add answer");
		if (check > 0) {

			System.out.println("inside trans add answer");
//			Transaction transaction=session.beginTransaction();
//			transaction.commit();
		}

		return check;
	}

	// get All question by category
	public List<Question> getAllQuestionByCategory(String cat) {
		Session session = sessionFactory.getCurrentSession();
		Query q = session.createQuery("from Question where title=:category order by dateUpdated");
		q.setParameter("category", cat);
		List<Question> allQuesByCat = q.list();

		return allQuesByCat;
	}

	// Question asked by logined User
	public List<Question> getAllQuestionByLoginUser(String uname) {
		Session session = sessionFactory.getCurrentSession();
		Query q = session.createQuery("from Question where userName=:uname");
		q.setParameter("uname", uname);
		List<Question> allQuesByUser = (List<Question>) q.list();

		// System.out.println("all quess size "+allQuesByUser);
		return allQuesByUser;
	}

	// Answered by logined User
	public List<Answer> getAllAnsweredByLoginUser(String username) {
//			 SQLQuery query = (SQLQuery) sessionFactory.openSession().createSQLQuery("select q.question,q.datecreated,a.answerDate,a.answer from questions q inner join answers a on q.questionid=a.qid where a.usernameAnswer=:username order by q.question");
//			 query.setParameter("username", username);
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from Answer where usernameAnswer=:username");
		query.setParameter("username", username);
		List<Answer> allAnsByUser = (List<Answer>) query.list();

		return allAnsByUser;
	}

	// Report answer
	public int reportAnswer(ReportAnswer reportAnswer) {
		Session session = sessionFactory.getCurrentSession();
		int check = (Integer) session.save(reportAnswer);
		if (check > 0) {
//			Transaction transaction=session.beginTransaction();
//			transaction.commit();
//			
		}
		return check;
	}

	// Report Question
	public int reportQuestion(ReportQuestion reportQuestion) {
		Session session = sessionFactory.getCurrentSession();
		int check = (Integer) session.save(reportQuestion);
		if (check > 0) {
//			Transaction transaction=session.beginTransaction();
//			transaction.commit();
		}
		return check;
	}

	// save contact
	public String saveContactUs(Contactus contactus) {
		Session session = sessionFactory.getCurrentSession();
		int check = (Integer) session.save(contactus);
		if (check > 0) {
			return "Thank you for contacting us!";
		} else {
			return "Something went wrong!";
		}
	}

	// Search Question
	public List<Question> searchQuestion(String searchText) {
		Session session = sessionFactory.openSession();
		Query q = session.createQuery("from Question where question like ?");
		q.setParameter(0, "%" + searchText + "%");
		List<Question> searchResult = (List<Question>) q.list();
		return searchResult;
	}

}
